package org.factoryDesignpattern;

public class DellLaptop implements Laptop  {
    @Override
    public void laptopSpecial() {
        System.out.println("Most useful and ordered laptop in de world");
    }
}
