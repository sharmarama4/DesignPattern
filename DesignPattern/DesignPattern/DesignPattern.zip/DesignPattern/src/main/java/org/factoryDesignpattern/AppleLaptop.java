package org.factoryDesignpattern;

public class AppleLaptop implements Laptop {
    @Override
    public void laptopSpecial() {
        System.out.println("Most secured laptop in de world");
    }
}
