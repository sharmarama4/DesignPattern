package org.factoryDesignpattern;

public class HpLaptop implements Laptop{
    @Override
    public void laptopSpecial() {
        System.out.println("Not so much used in today's world");
    }
}
