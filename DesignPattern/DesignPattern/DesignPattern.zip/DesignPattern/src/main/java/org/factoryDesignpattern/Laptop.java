package org.factoryDesignpattern;

public interface Laptop {
    void laptopSpecial();
}
