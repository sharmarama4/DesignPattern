package org.prototype;

public enum GameType {
    LUDO,PUBG
}
